# lab1_20182
Laboratorio 1 de Informatica 2 semestre 2018_2
Clone este repositorio y copie el archivo lab1_code.cpp a su propio repositorio

